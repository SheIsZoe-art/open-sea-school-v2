# Open Sea School V2 — L’école du grand large

A project by **KETH / BEKW-code**. **SheIsZoe** is the production assistant, with AI-assisted implementation.

> « J’ai aimé mettre un coup de tournevis pour KETH. Tout est à lui. »
>
> “I enjoyed lending a screwdriver to KETH. This is his project.”

Playful, free learning for children and teenagers, designed to work offline on modest devices. No account, advertising, tracking, subscription, remote AI or downloaded font is needed to use the school. Illustrations and optional short sounds are generated locally. Low energy use is a design aim; no measured energy savings are claimed.

## Open the school

[Play online / Jouer en ligne](https://sheiszoe-art.github.io/open-sea-school-v2/)

- [English school](en/OPEN-SEA-SCHOOL.html)
- [École française](fr/OPEN-SEA-SCHOOL.html)
- [Download the offline edition](Open-Sea-School-V2-Offline.zip)
- [Choose your language](index.html)

Download the ZIP, extract it and open **index.html**. Keep its `en/` and `fr/` folders beside that file. No installation, server or network is required for lessons and games. External creator references require a connection. Modern browsers are supported; animation reduction is respected.

## What is included

Each language contains **810 course entries**: nine subject areas × nine age bands (roughly 6–15) × ten courses. Each entry connects to a playable activity and a scripted, six-stage Captain Claw lesson. The French classroom is Capitaine Pince; the English classroom has native English instructions. Language subject exercises may intentionally contain the language being studied.

The activities use **25 shared interaction families**, with course-specific prompts, parameters and procedural variations where supported. This is not a claim of 810 unrelated game engines. The English and French explanatory lessons differ in their examples and editorial treatment. Advanced titles and replay counts do not establish complete curriculum coverage.

The school also includes the lobster studio, sea jokes, arcade, brain teasers, sandpit, practical life topics, journals and offline support documents. The classroom opens without restarting the school activity. Returning to the game preserves the live mission. The classrooms do not award school-game medals. English and French journals are separate; export progress regularly, since browser storage can be cleared and file-based storage behaviour varies between browsers.

## Verification and educational limits

Automated checks cover all **1,620 course entries**, their teacher links, six teaching stages per entry, valid and invalid solutions across 12 configurations per game, slider limits and all 25 game families. See [the audit](VERIFICATION-V2.json).

These checks simulate documents and interactions. They do **not** replace tests on real devices, teaching review, accessibility assessment or trials with learners. The lessons are an educational prototype, not an accredited school, qualification, complete national curriculum or evidence of general cognitive improvement. See each language’s sources and coverage page.

## Creator, credits and rights

The original idea and project belong to **KETH**. Attribution does not imply his approval of each lesson or change.

- [KETH’s GitHub](https://github.com/BEKW-code)
- [KETH’s gists](https://gist.github.com/BEKW-code)
- [NightCafe artwork](https://creator.nightcafe.studio/u/KetharMolisheNuvahel)
- [Suno music](https://suno.com/@hardtogovern)
- [Artist profile](https://www.einpresswire.com/article/944403908/the-eternal-wizard-king-builds-a-genre-defying-soundworld-from-ai-open-source-and-cosmic-stand-up)

Read [the credits](en/CREDITS.html), [the French credits](fr/CREDITS.html), [LICENSE](LICENSE) and [RIGHTS.md](RIGHTS.md). MIT applies to the adaptation’s own contributions; pre-existing works retain their owners’ rights and conditions. No ownership of third-party work is transferred by these credits.

## Edit and rebuild

The delivered HTML files run without development tools. For contributors, Node.js 18+ is enough; no dependency installation is needed.

```sh
npm run build
npm test
```

`source/` holds the V2 interface modules, styles, English localization and English classroom. `source-templates/` holds the original credited school engines, French classroom master and language landing page. `scripts/build.cjs` rebuilds both schools and classrooms. Other HTML support documents can be edited directly. The offline ZIP is regenerated separately from the delivered language folders, avoiding source-template duplication.

The V1 repository is preserved. V2 is a separate repository and release line.

## En français

Ouvre **index.html**, choisis ta langue puis une matière. Chaque parcours propose dix cours, leur mini-jeu et une explication du capitaine. Les deux versions sont séparées et jouables hors connexion. Le projet reste un prototype pédagogique à relire avec des enseignants et à tester sur de vrais appareils. Les crédits de KETH et le rôle d’assistante de réalisation de SheIsZoe sont conservés.

## Install the school as an app / Installer l’école

On the HTTPS website, choose **Install the school**, then confirm the browser prompt where supported. On iPhone or iPad, the page explains how to use Safari’s Share → Add to Home Screen. Native prompts depend on browser support and cannot be forced.

Choose **Save for offline use** and select French, English or both. Wait for the ready message before disconnecting. Download progress is shown; file integrity is checked before a language package is marked ready. A failed update keeps that language’s previous complete copy. Preparing offline content does not change the learner journal.

The installed icon and saved lessons are separate steps. Browser storage may be removed by the device; export your journal and keep the ZIP for a separate portable copy. Local HTML files already work offline but cannot install a service worker; use the online site to install the app icon.

[Installation page](INSTALL.html). On the French site: **Installer l’école**, puis **Préparer hors connexion**. Le ZIP reste disponible.

### Offline reliability update

The initial app package now saves both schools, both guided classrooms, the language welcome pages and creator credits. Keep the first connection active until the ready message appears. The language selector prepares the remaining manuals and support documents. Readiness checks confirm the actual cached files, not just a cache folder. A missing page shows a recovery screen with links to the cached welcome and installation pages instead of a plain error message. On devices with separate installed-app storage, open the installed app online once and check readiness there before disconnecting.

## Stable, Classic and Preview

- `/` is the stable school. Its interface remains classic; the 8-bit update is not promoted automatically. Existing stable journals keep their original storage keys.
- `/classic/` is the preserved classic baseline. Its frozen delivery templates live in `source-templates/classic-delivery/`; rebuilds do not replace them from current Stable.
- `/preview/` is the 8-bit test edition with cumulative and per-subject XP. It is a pre-release, not a replacement for Stable.

Each edition has separate journal keys, app identity, service-worker scope and cache prefix. Preview XP uses its own namespace. Trying Preview therefore starts a separate record. You can explicitly export and import a journal to move supported progress; Stable does not understand Preview-specific XP. Keep your export before switching.

The version bar links all three editions. Every edition has its own offline ZIP and installer. `npm run build` regenerates the versioned copies; `node scripts/verify-versions.cjs` checks storage and cache isolation.

### Returning to an earlier version

The `v2.0.0` release preserves the exact public baseline before the 8-bit Preview, with its original offline ZIP. Tags are kept as fixed checkpoints. The next update is released as `v2.1.0-preview.1` while Stable remains at the main address. To roll back a future promotion, create a new commit restoring the stable delivery from its saved tag, or revert the promotion commit, then publish normally. Do not reset or force-push shared history. An installed app may need to reopen online to receive the rollback; restoring code does not itself restore learner journals.
